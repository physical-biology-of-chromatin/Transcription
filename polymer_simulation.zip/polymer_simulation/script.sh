#!/bin/bash

nchain=9827         #number of monomers in the polymer
l=17                #size of the box
neq=100000          #number of MCS to reach steady state
nmeas=100           #number of frames
ninter=1000         #number of MCS between each two frames
kint=1.2            #bending stifness
ngene=1             #number of genes in the chromosome
genelength=50       #length of the gene
e=-3.0              #strength of interaction between Pol II-Pol II
val=2               #the interaction valency number 
initiation0=0.00006 #bounding rate
initiation=0.0001   #initiation rate
elongation=0.0001   #elongation rate
termination=0.00004 #termination (or unbounding) rate
rcap=1.0            #radius of capture of HiC analysis (in lattice unit)

t=$((4*${l}*${l}*${l}))
pn=$((1+${genelength}))
sv=$((1+${val}))

sed -i.back -e '1c\'$'\n '$nchain' ::Nchain' input.dat
sed -i.back -e '2c\'$'\n '$l' ::L' input.dat
sed -i.back -e '3c\'$'\n '$neq' ::Neq' input.dat
sed -i.back -e '4c\'$'\n '$nmeas' ::Nmeas' input.dat
sed -i.back -e '5c\'$'\n '$ninter' ::Ninter' input.dat
sed -i.back -e '6c\'$'\n '$kint' ::kint' input.dat
sed -i.back -e '7c\'$'\n '$ngene' ::Ngene' input.dat
sed -i.back -e '8c\'$'\n '$genelength' ::geneLength' input.dat
sed -i.back -e '9c\'$'\n '$e' ::Epp' input.dat
sed -i.back -e '10c\'$'\n '$val' ::valancy' input.dat
sed -i.back -e '11c\'$'\n '$initiation0' ::InitiationRate0' input.dat
sed -i.back -e '12c\'$'\n '$initiation' ::InitiationRate' input.dat
sed -i.back -e '13c\'$'\n '$termination' ::TerminationRate' input.dat
sed -i.back -e '14c\'$'\n '$elongation' ::ElongationRate' input.dat
sed -i.back -e '15c\'$'\n '$rcap' ::Rcap' input.dat
sed -i.back -e '3c\'$'\n integer,dimension(2,'$nchain') ::config' global.var
sed -i.back -e '4c\'$'\n integer,dimension(15,'$t') ::bittable' global.var
sed -i.back -e '8c\'$'\n real,dimension(3,'$nchain') ::dr' global.var
sed -i.back -e '9c\'$'\n integer,dimension('$nchain') ::state' global.var
sed -i.back -e '10c\'$'\n integer,dimension(3,'$ngene') ::gene' global.var
sed -i.back -e '11c\'$'\n integer,dimension('$pn','$ngene') ::poly' global.var
sed -i.back -e '12c\'$'\n integer,dimension('$sv','$nchain') ::contact' global.var


make clean
make
echo 'Lunching the program'
time ./lat

